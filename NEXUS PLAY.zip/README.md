# NEXUS PLAY — Projeto completo

Arquivos do projeto:
- `index.html`: estrutura e conteúdo do site.
- `style.css`: identidade visual, layout, responsividade e estilos.
- `script.js`: interações, busca, filtros, favoritos e controles.
- `README.md`: instruções de execução.

## Executar
1. Extraia todos os arquivos mantendo-os na mesma pasta.
2. Abra `index.html` no navegador.
3. Para desenvolvimento, recomenda-se VS Code com Live Server.

## Observação
Imagens e fontes podem depender de conexão à internet. Recursos de login, formulário/newsletter são demonstrativos e não enviam dados a um servidor.
